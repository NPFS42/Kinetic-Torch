package com.npfs.stars.kinetictorch

import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ChopTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        syncTileState()
    }

    override fun onClick() {
        super.onClick()
        val prefs = getSharedPreferences(ChopDetectionService.PREFS_NAME, Context.MODE_PRIVATE)
        val currentlyEnabled = prefs.getBoolean(ChopDetectionService.KEY_SERVICE_ENABLED, false)
        val newState = !currentlyEnabled

        prefs.edit().putBoolean(ChopDetectionService.KEY_SERVICE_ENABLED, newState).apply()

        val serviceIntent = Intent(this, ChopDetectionService::class.java)
        if (newState) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } else {
            // Centralized stopService triggers onDestroy() -> shutdownTorchAndCleanup()
            stopService(serviceIntent)
        }
        syncTileState()
    }

    private fun syncTileState() {
        val tile = qsTile ?: return
        val prefs = getSharedPreferences(ChopDetectionService.PREFS_NAME, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(ChopDetectionService.KEY_SERVICE_ENABLED, false)

        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (enabled) "Chop Torch: ON" else "Chop Torch: OFF"
        tile.updateTile()
    }
}
